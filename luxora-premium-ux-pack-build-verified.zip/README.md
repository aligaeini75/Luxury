# Luxora Ultimate Merged Fullstack

این نسخه همه تغییرات بعد از پیام اصلی را یکجا merge کرده است:

## Features
- Role-based system: `man`, `woman`, `admin`
- Cinematic landing + luxury login/register
- Man profile studio:
  - main photo
  - gallery
  - general interests
  - date-specific interests
  - voice intro URL
  - video intro URL
  - profile preview shown to women
- Woman studio:
  - pricing atelier
  - monthly gallery price
  - public/private access price
  - luxury calendar
  - services
  - date/time-specific locations
  - incoming requests accept/reject/counter
- Wallet:
  - balance
  - locked balance
  - USDT deposit invoice
  - withdrawal request
  - transaction timeline
- Escrow:
  - create hold
  - release/refund/dispute by admin
- Chat:
  - chat rooms
  - messages
  - unread counters
  - online status
  - typing-ready UI
- Notifications:
  - notification center
  - mark read/read all
- VIP tiers:
  - tier catalog
  - subscription records
- AI moderation scaffold:
  - moderation queue
  - risk flags
  - admin decision flow
- Admin Pro:
  - dashboard/KPIs
  - users
  - wallets/withdrawals
  - escrows
  - bookings
  - KYC
  - media moderation
  - tickets with replies
  - risk flags
  - VIP tiers

## Fresh D1 setup

حتماً با D1 جدید بالا بیار:

```bash
cd backend
wrangler d1 create luxora_ultimate_db
```

`database_id` خروجی را داخل `backend/wrangler.toml` جایگزین کن:

```toml
[[d1_databases]]
binding = "DB"
database_name = "luxora_ultimate_db"
database_id = "YOUR_DATABASE_ID"
```

بعد migration:

```bash
wrangler d1 migrations apply luxora_ultimate_db --remote
```

برای لوکال:

```bash
wrangler d1 migrations apply luxora_ultimate_db --local
```

Secret:

```bash
wrangler secret put JWT_SECRET
```

مقدار پیشنهادی:

```txt
LxR_Ultimate_2026#9vK!Qm$PrivateClub^SecureJwt
```

اختیاری برای USDT:

```bash
wrangler secret put USDT_DEPOSIT_ADDRESS
```

Deploy:

```bash
cd ../frontend
npm install
npm run build

cd ../backend
npm install
wrangler deploy
```

## Demo accounts

بعد از migration:

- admin: `admin@luxora.local` / `password123`
- man: `man@luxora.local` / `password123`
- woman: `woman@luxora.local` / `password123`

## Important
This project is structured as a premium private social access platform. Keep terms, moderation, KYC, consent and local law compliance strict.


## Hash Routing Fix

This version fixes Cloudflare Worker 404 after login by using Vue hash routing:

- `createWebHashHistory()`
- login redirects to:
  - `/#/admin`
  - `/#/man`
  - `/#/woman/studio`
- logout redirects to `/#/login`
- `wrangler.toml` keeps SPA fallback.

After replacing files:

```bash
cd frontend
npm install
npm run build

cd ../backend
npm install
wrangler deploy
```


## Role UI/Menu Fix Included

This version fixes:
- Separate sidebar menus for men and women.
- Woman menu includes Studio, Requests, Gallery Store, Extra Services, Locations Calendar, Availability, Wallet Withdraw, Chat, Notifications.
- Man menu includes Overview, Discover Women, Profile Studio, My Gallery, Interests, Wallet Deposit, Chat, Notifications.
- Woman wallet removes deposit UI; only withdrawals.
- Raw image URL fields replaced with luxury upload cards on key pages.
- New frontend routes:
  - `/#/woman/gallery`
  - `/#/woman/services`
  - `/#/woman/locations`
  - `/#/woman/calendar`
  - `/#/woman/wallet`
  - `/#/man/gallery`
  - `/#/man/interests`
- Upload API:
  - `POST /api/uploads/image`
  - Uses Cloudinary if these env vars are set:
    - `CLOUDINARY_CLOUD_NAME`
    - `CLOUDINARY_UPLOAD_PRESET`
  - Otherwise returns a development placeholder image.

Optional Cloudinary setup:
```bash
wrangler secret put CLOUDINARY_CLOUD_NAME
wrangler secret put CLOUDINARY_UPLOAD_PRESET
```


## Upload Everywhere Fix

This version replaces remaining image URL inputs in key UI flows with luxury upload cards:

- Men main photo upload
- Men gallery upload
- Women profile cover upload
- Women gallery store upload
- Women service cover upload
- Women location cover upload

Also added:
- `woman_gallery` table
- `/api/woman/gallery`
- gallery data returned from `/api/woman/studio`

Voice/video intro fields are still URL-based intentionally because they are media files, not image covers. They can be upgraded to audio/video upload in the next phase.


## Voice / Video Upload Upgrade

Voice and video intro URL inputs were replaced with luxury media upload cards:
- Voice intro uploader
- Video intro uploader
- Audio/video preview inside cards
- Luxury cinematic media UI


## Landing Anchor Navigation Fix

Top navbar section buttons now use `scrollIntoView()` instead of raw `href="#section"` links.  
This fixes Vue hash-router conflict where `#experience`, `#trust`, `#vip`, `#faq` were treated like routes instead of page anchors.


## 12 Luxury Layers Added

This build adds/extends the 12 requested upgrades:

1. Cinematic Intro Mode
2. Ultra Premium Profile Hero
3. Apple-level Multi-step Booking Flow
4. Netflix/Tinder Hybrid Discover Rows
5. Realtime Presence UI foundation
6. Cinematic USDT Wallet UX foundation
7. VIP Tier economy UI/data
8. AI Concierge scaffold
9. Auction/Bid system
10. Private Circle system
11. Protected media/audit infrastructure tables
12. Mobile-app style bottom dock and snap-ready layout

New routes:
- `/#/man/concierge`
- `/#/man/auctions`
- `/#/circles`

New API modules:
- `/api/ai/concierge-plan`
- `/api/auctions`
- `/api/circles`

New tables:
- `auctions`
- `auction_bids`
- `private_circles`
- `media_access_tokens`
- `audit_logs`


## All Enhancements Except Voice AI Concierge

Added everything from the previous suggestion except item 5 (Voice AI Concierge):

- Real native/mobile feel foundation
- Hidden/invite-only economy extension
- Live luxury events
- Blur-to-unlock galleries
- Reputation/trust graph cards
- Realtime dynamic UI toasts
- Cinematic chat
- Concierge marketplace
- Protected media tables and access token flow
- Luxury analytics panel
- Dynamic theme engine
- AI moderation remains scaffolded from prior build
- Financial/escrow layer extended
- Ultra premium discover/reels style

New frontend routes:
- `/#/events`
- `/#/protected-gallery`
- `/#/cinematic-chat`
- `/#/marketplace`
- `/#/woman/analytics`
- `/#/mobile-preview`

New API routes:
- `/api/events`
- `/api/protected-gallery`
- `/api/marketplace/services`
- `/api/analytics/woman`

New DB tables:
- `live_events`
- `protected_gallery_items`
- `concierge_services`


# Final Ultimate Ecosystem Merge

This build includes all previous changes plus the complete latest enhancement batch:

1. Full cinematic reels system
2. Emotion-based adaptive UI
3. AI luxury feed ranking foundation
4. Dynamic cinematic sound toggle
5. Holographic UI effects
6. Elite economy and invite passes
7. Full escrow dispute center
8. AI risk engine
9. Invisible status system
10. Invite codes / scarcity
11. Luxury timeline system
12. Hyper-visual wallet
13. Push notification infrastructure foundation
14. Private jet / yacht layer
15. Production media CDN foundation
16. AI generated luxury scene concepts
17. Shadow / ghost mode
18. Ultra premium admin HQ
19. Dynamic seasonal modes
20. Cohesive motion system

New frontend routes:
- `/#/reels`
- `/#/elite`
- `/#/disputes`
- `/#/risk-engine`
- `/#/status`
- `/#/timeline`
- `/#/hyper-wallet`
- `/#/push`
- `/#/ultra-marketplace`
- `/#/media-cdn`
- `/#/ai-scenes`
- `/#/ghost`
- `/#/seasonal-modes`
- `/#/admin/hq`

New DB tables:
- `invite_codes`
- `elite_passes`
- `escrow_disputes`
- `ai_risk_signals`
- `luxury_moments`
- `push_tokens`
- `ultra_marketplace_items`
- `seasonal_theme_events`
- `status_badges`
- `feed_ranking_events`

Fresh deploy steps:
```bash
cd backend
wrangler d1 create luxora_ultimate_final_db
# put new database_id in wrangler.toml
wrangler d1 migrations apply luxora_ultimate_final_db --remote
wrangler secret put JWT_SECRET
wrangler deploy
```

Then:
```bash
cd ../frontend
npm install
npm run build
cd ../backend
wrangler deploy
```


# Production Wired Build

Added:
- NOWPayments invoice support with demo fallback
- NOWPayments IPN endpoint `/api/payments/nowpayments/ipn`
- Unified booking flow: woman accepts → escrow auto-locks → chat room unlocks → notification sent
- Admin audit logs
- Admin dispute arbitration: release/refund/split
- Admin user detail and session revoke
- Provider settings UI
- Rate limiting middleware
- Skeleton/empty state components
- D1 tables for provider settings, rate limits, sessions, signed media links

New frontend routes:
- `/#/admin/audit-logs`
- `/#/admin/disputes`
- `/#/admin/users/:id`
- `/#/admin/providers`

Required secrets:
```bash
wrangler secret put JWT_SECRET
wrangler secret put NOWPAYMENTS_API_KEY
wrangler secret put NOWPAYMENTS_IPN_SECRET
wrangler secret put R2_SIGNING_SECRET
wrangler secret put PUSH_PROVIDER_KEY
wrangler secret put OPENAI_API_KEY
```

Fresh deploy:
```bash
cd backend
wrangler d1 create luxora_production_wired_db
# put database_id into wrangler.toml
wrangler d1 migrations apply luxora_production_wired_db --remote

cd ../frontend
npm install
npm run build

cd ../backend
npm install
wrangler deploy
```


# Real Ops Except SEO Merge

Implemented all requested items except city SEO pages:

- Real NOWPayments integration path
- Cloudflare R2 upload path + protected media serving
- Durable Objects WebSocket chat scaffold
- Stronger admin: wallet monitor, monitoring, disputes, user detail, providers, audit
- Terms/legal/safety page
- Money MVP flow foundation: request → accept → escrow lock → chat unlock
- Strong public women profile page
- Platform fee foundation
- Monitoring/error logging foundation

New routes:
- `/#/terms`
- `/#/women/:id`
- `/#/admin/wallet-monitor`
- `/#/admin/monitoring`

New API:
- `/api/media/file/:key`
- `/api/public/women/:id`
- `/api/realtime/chat/:roomId`
- `/api/monitoring/client-error`
- `/api/admin/wallet-monitor`
- `/api/admin/monitoring`

Fresh deploy:
```bash
cd backend
wrangler d1 create luxora_real_ops_db
# update wrangler.toml database_id
wrangler d1 migrations apply luxora_real_ops_db --remote
wrangler secret put JWT_SECRET
wrangler secret put NOWPAYMENTS_API_KEY
wrangler secret put NOWPAYMENTS_IPN_SECRET
wrangler secret put PLATFORM_FEE_PERCENT
wrangler deploy
```


# No Fake Notifications / Real Data Cleanup

This build removes fake UI notification spam:
- `LiveToastStack` no longer creates interval-based fake notifications.
- It only polls `/api/notifications` and displays unread real records.
- Seed notifications are marked read so they do not pop on first load.

Also cleaned obvious schematic/fake UI:
- Mobile preview now links to real sections instead of fake screen slides.
- AI scene page no longer shows a placeholder image before generation.
- Push page stores a backend token record and explains provider wiring.
- Landing copy no longer says simulation.
