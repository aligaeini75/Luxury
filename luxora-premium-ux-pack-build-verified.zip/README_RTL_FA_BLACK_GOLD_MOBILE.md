# Luxora RTL Persian Black/Gold Mobile Upgrade

اعمال شده:
- کل سایت `dir="rtl"` و `lang="fa"`
- فونت فارسی Vazirmatn
- تم کاملاً مشکی/طلایی
- Landing فارسی و موبایل‌فرست
- سایدبار دسکتاپ راست‌چین و سمت راست
- Bottom navigation فارسی و بهتر برای موبایل
- Login/Register فارسی‌سازی شده
- PWA manifest فارسی + RTL
- PWA install prompt فارسی
- CSS global برای راست‌چین شدن ورودی‌ها، متن‌ها و layout

بعد از جایگزینی:
```bash
cd frontend
pnpm install
pnpm build
pnpm dev
```
