# Luxora FA/RTL fixed version

این نسخه از بیس سالم RTL ساخته شده و دیگر identifierهای TypeScript فارسی نشده‌اند.

اعمال شده:
- RTL و فارسی پیش‌فرض
- تم مشکی/طلایی
- فونت Vazirmatn
- PWA فارسی/RTL
- پنل‌ها و منوهای اصلی فارسی
- locale مرکزی `frontend/src/i18n/fa.ts`
- helperهای فارسی برای status/type/role/money/date
- کامپوننت `PersianStatusBadge.vue`

تست:
```bash
cd frontend
pnpm install
pnpm build
```
