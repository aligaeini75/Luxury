# راهنمای تست نهایی Luxora

## تست‌های اصلی
1. ثبت‌نام مرد، زن و ورود ادمین
2. تکمیل پروفایل و احراز هویت مرد/زن
3. تایید یا رد KYC از ادمین
4. ساخت تایم زن با دیت حضوری، عکس لوکیشن، سرویس اضافه و قیمت نهایی
5. رزرو مرد با نمایش تاریخ شمسی، لوکیشن و سرویس‌ها
6. تایید درخواست توسط زن
7. نمایش اختلاف و درخواست باز شدن زودتر فقط بعد از تایید زن
8. تست چت/ویدیو فقط از داخل رزرو معتبر
9. تست کیف پول، escrow، ریفاند و آزادسازی
10. تست ادمین: کاربران، رزروها، تیکت‌ها، KYC و اختلاف‌ها

## اگر migration تیکت خطا داد
اگر `ticket_locked` وجود نداشت، یک بار دستی اجرا کن:

```sql
ALTER TABLE users ADD COLUMN ticket_locked INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN admin_note TEXT DEFAULT '';
CREATE INDEX IF NOT EXISTS idx_users_ticket_locked ON users(ticket_locked);
```

## دستورهای deploy
```bash
cd frontend
pnpm install
pnpm run build

cd ../backend
pnpm install
pnpm run typecheck

wrangler d1 migrations apply DB --remote
wrangler deploy
wrangler tail
```
