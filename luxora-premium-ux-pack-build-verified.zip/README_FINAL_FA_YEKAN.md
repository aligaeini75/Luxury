# نسخه نهایی فارسی / RTL / فونت یکان

اعمال شده:
- فارسی‌سازی گسترده پنل مرد، خانم و ادمین
- ادمین RTL و راست‌چین‌تر شد
- سایدبارها راست‌چین و مناسب RTL
- فونت پیش‌فرض به خانواده یکان تغییر کرد:
  `IRANYekanX`, `IRANYekan`, `Yekan Bakh`, `BYekan`, fallback به `Vazirmatn`
- متن‌های رایج انگلیسی در دکمه‌ها، جدول‌ها، منوها، statusها و actionها فارسی شدند
- فایل audit برای متن‌های انگلیسی باقی‌مانده:
  `ENGLISH_LEFTOVERS_AUDIT.txt`
- اسکن identifierهای خراب:
  `BUILD_IDENTIFIER_SCAN.txt`

نکته فونت:
فایل فونت داخل پروژه قرار داده نشده. مرورگر از فونت نصب‌شده سیستم استفاده می‌کند و اگر نبود به Vazirmatn/Tahoma برمی‌گردد.
برای فونت اختصاصی، فایل فونت را خودت در `public/fonts` قرار بده و مسیرش را در `src/style.css` بده.

تست:
```bash
cd frontend
pnpm install
pnpm build
pnpm dev
```
