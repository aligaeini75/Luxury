# Black/Gold Theme + Mobile PWA Upgrade

Applied:
- Full black/gold visual identity across global Tailwind theme and CSS utilities.
- Removed purple/pink ambient identity from global effects.
- Mobile-first responsive landing with horizontal profile cards and safe-area sticky CTA.
- PWA manifest, SVG app icons, service worker and install prompt.
- iOS/Android meta tags and standalone display support.
- Mobile bottom navigation redesigned for PWA safe area.
- Admin/user shells adjusted for black/gold and mobile behavior.

Run:
```bash
cd frontend
npm install
npm run build
npm run dev
```

PWA test:
- Build and serve over HTTPS or localhost.
- Open Chrome DevTools > Application > Manifest / Service Workers.
- On mobile Chrome use “Add to Home screen”.
- On iOS Safari use Share > Add to Home Screen.
