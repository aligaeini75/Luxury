# Luxora launch-ready core changes

This package keeps the existing luxury UI and adds only launch-critical infrastructure:

- NOWPayments invoice callback with IPN HMAC verification.
- Wallet holds for booking requests.
- Escrow refund on reject and net creator payout on admin release.
- Platform fee tracking in `platform_fees`.
- R2 private media URLs with HMAC expiry tokens.
- Upload size/type validation.
- Gallery subscription payout and subscriber notifications.
- Booking request notifications for men and women.
- Video-call backend time-window enforcement.
- LiveKit token generation when `LIVEKIT_*` env vars are configured.
- Sidebar alert popover for unread notifications.
- Basic watermark overlay for unlocked gallery images.
- Admin layout z-index/spacing fix.

## Setup

```bash
cd backend
cp .dev.vars.example .dev.vars
npm install
npx wrangler d1 migrations apply luxora_db --local
npm run dev
```

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

## Production env

Set these Cloudflare Worker variables/secrets:

```txt
JWT_SECRET
APP_URL
PLATFORM_FEE_PERCENT
NOWPAYMENTS_API_KEY
NOWPAYMENTS_IPN_SECRET
R2_SIGNING_SECRET
LIVEKIT_URL
LIVEKIT_API_KEY
LIVEKIT_API_SECRET
```

Bind these resources in `wrangler.toml`:

- D1 database as `DB`
- R2 bucket as `MEDIA_BUCKET`
- Durable Object namespace as `CHAT_DO`

## Important payment flow

1. Man tops up wallet through NOWPayments.
2. IPN verifies signature and credits wallet.
3. Man sends Date/Chat/Video request and amount is moved from balance to locked balance.
4. Woman accepts or rejects.
5. Reject refunds immediately.
6. Accept unlocks chat/video room and keeps escrow funded.
7. Admin releases escrow after completion; creator receives net payout after platform fee.
